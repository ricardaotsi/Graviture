#pragma strict
static var f:int=1;
function teste()
{
	f++;
	Debug.Log (f.ToString());
}